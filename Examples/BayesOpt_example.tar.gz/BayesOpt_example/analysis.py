import sys
sys.path.append("/home/sma86/packages")

from PyGMINBayesOpt import analyse_runs

num_runs = 100
topo_batch_flag = True
disconnection_exec = "/home/sma86/softwarewales/DISCONNECT/build/disconnectionDPS"

params = {
    "sampling_mode": 1, # Int. Method of sampling points via AF: single global minima (0) or topological batch selection (1)
    "hyperparams_flag": True, # Bool.True if BayesOpt GMIN hyperparams file needed
    "gpplateau_flag": True, # Bool.True if BayesOpt GMIN gpplateau file needed
    "E_max": 15.35237412, # Float. Values in "response" file above E_max are truncated to E_max
    "a_max": 1.5, # Float. Maximum cell length.
    "a_min": 0.5, # Float. Minimum cell length.
    "a_bound_width": 0.2, # Float. Cell length width that is considered "bounds" region.
    "v_min": 0, # Float. Minimum cell volume.
    "angle_min": 0, # Float. Minimum cell angle in radians.
    "angle_max": 3.1415, # Float. Maximum cell angle in radians.
    "angle_bound_width": 0.349066, # Float. Cell angle width that is considered "bounds" region.
    "cluster_flag": False, # Bool. If true, cell information is ignored.
    "ortho_flag": False, # Bool. If true, min_angle and max_angle parameters are ignored and all cell angles are set to 90 deg.
    "dftbp_flag": False, # Bool. If true, program prepares dftbp_in.hsd file instead of coords.
    "gmin_exec": "/home/sma86/softwarewales/GMIN/builds/compiler/GMIN", # String. Path to GMIN executable.
    "dftbpgmin_exec": "/home/sma86/softwarewales/GMIN/builds/ifort_dftbp/DFTBPGMIN", # String. Path to DFTBPGMIN executable.
    "bayesopt_optim_exec": "/home/sma86/walesibm/OPTIM/builds/ifort/OPTIM", # String. Path to BayesOpt OPTIM executable.
    "bayesopt_pathsample_exec": "/home/sma86/walesibm/PATHSAMPLE/builds/ifort/PATHSAMPLE", # String. Path to BayesOpt PATHSAMPLE executable.
    "alpha": 0.8, # Float. Sets energy cutoff threshold during topological batch selection.
    "beta": 0.2, # Float. Sets barrier cutoff threshold during topological batch selection.
    "batch_size": 3 # Int. Number of minima to be sampled during topological batch selection.
    }

analyse_runs(num_runs, params, topo_batch_flag, disconnection_exec)