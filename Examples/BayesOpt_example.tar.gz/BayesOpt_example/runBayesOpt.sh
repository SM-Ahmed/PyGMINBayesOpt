#!/bin/bash

for num in {1..100};
do 
cd run$(printf "%0d" $[num]);
/home/sma86/walesibm/GMIN/source/GMIN;
python bayesopt.py;
cd ..;
mv run$(printf "%0d" $num)/next_run/ run$(printf "%0d" $[num+1]);
done