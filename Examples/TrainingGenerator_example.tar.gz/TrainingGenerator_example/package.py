import sys
sys.path.append("/home/sma86/packages")

from PyGMINBayesOpt import training_generator, gen_training, gen_response, gen_bounds, cleanup, join_bounds

params = {
"n_atoms": 1, # Int. No. atoms per unit cell. 
"n_configs": 500, # Int. No. cell configurations to be generated.
"n_configs_bounds": 0, # Int. No. cell configurations to be generated in bounds region of config space.
"a_max": 1.5, # Float. Maximum cell length.
"a_min": 0.5, # Float. Minimum cell length.
"a_bound_width": 0.2, # Float. Cell length width that is considered "bounds" region.
"v_min": 0, # Float. Minimum cell volume.
"angle_min": 0, # Float. Minimum cell angle in radians.
"angle_max": 3.1415, # Float. Maximum cell angle in radians.
"angle_bound_width": 0.349066, # Float. Cell angle width that is considered "bounds" region.
"min_bond_length": 0.8, # Float. Minimum acceptable distance between any pair of atoms
"origin": 0.5, # Float. Fixed fractional coordinate of first atom in all three dimensions.
"ortho_flag": False, # Bool. If true, min_angle and max_angle parameters are ignored and all cell angles are set to 90 deg. 
"cluster_flag": False, # Bool. If true, program does not generate cell length and cell angle features.
"E_max": 3, # Float. Values in "response" file above E_max are truncated to E_max
"autoEmax_flag": True, # Bool. If true, E_max parameter is ignored. Instead, program takes E_max as the modulus of the lowest negative value in "response".
"cleanup_flag": True, # Bool. If true, program begins by deleting contents of "coords", "singlepoint" and "BayesOpt" folders.
"dftbp_flag": False, # Bool. If true, program prepares dftbp_in.hsd file instead of coords.
"gmin_exec": "/home/sma86/softwarewales/GMIN/builds/compiler/GMIN", # String. Path to GMIN executable.
"dftbpgmin_exec": "/home/sma86/softwarewales/GMIN/builds/ifort_dftbp/DFTBPGMIN" # String. Path to DFTBPGMIN executable.
}

training_generator(params)